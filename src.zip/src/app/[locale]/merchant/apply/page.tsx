import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { MerchantApplicationPanel } from "@/components/auth/MerchantApplicationPanel";
import type { SiteLocale } from "@/lib/i18n/site-copy";

const locales: SiteLocale[] = ["en", "ar"];

export const metadata: Metadata = {
  title: "Shop owner space | KULHA!",
  robots: { index: false },
};

export default async function LocalizedMerchantApplyPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  if (!locales.includes(locale as SiteLocale)) notFound();
  return <MerchantApplicationPanel />;
}
